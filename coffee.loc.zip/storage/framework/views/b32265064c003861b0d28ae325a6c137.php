
<ui-menu-checkbox-group <?php echo e($attributes); ?> data-flux-menu-checkbox-group>
    <?php echo e($slot); ?>

</ui-menu-checkbox-group>
<?php /**PATH H:\OSPanel\home\coffee.loc\vendor\livewire\flux\stubs\resources\views\flux\menu\checkbox\group.blade.php ENDPATH**/ ?>