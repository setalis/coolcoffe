<div class="flex h-screen items-center justify-center">
    <div class="container flex mx-auto px-4 py-8 items-center justify-center">
        <div class="max-w-3xl mx-auto p-4 md:p-6 bg-amber-50 border border-amber-200 rounded-xl">
            <!-- Progress indicator with labels -->
            <div class="mb-8">
                <div class="flex w-full items-start justify-between relative px-2 overflow-hidden">
                    <?php
                        $steps = [
                            1 => 'Контактные данные',
                            2 => 'Адрес доставки',
                            3 => 'Подтверждение'
                        ];
                    ?>

                    <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col items-center min-w-[70px] md:min-w-0">
                            <div class="w-10 h-10 rounded-full flex items-center justify-center 
                                <?php echo e($step > $i ? 'bg-amber-600' : ($step === $i ? 'bg-cyan-500' : 'bg-gray-300')); ?>">
                                <span class="text-white font-bold text-sm"><?php echo e($i); ?></span>
                            </div>
                            <span class="hidden md:block mt-1 text-xs md:text-sm text-center w-20 text-gray-600"><?php echo e($label); ?></span>
                        </div>
                        <?php if(!$loop->last): ?>
                            <div class="flex-1 h-1 bg-gray-300 mx-1 md:mx-2 relative top-5">
                                <div class="h-1 bg-cyan-500 transition-all duration-300" style="width: <?php echo e($step > $i ? '100%' : '0%'); ?>"></div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Step 1: Контактные данные -->
            <?php if($step === 1): ?>
                <div class="bg-white rounded-xl shadow p-4 mb-6">
                    <div class="flex items-center gap-4">
                        <img src="<?php echo e(asset('storage/' . $coffee->image)); ?>" alt="Product image" class="w-auto h-[100px] object-cover rounded pe-3">
                        <div class="border-l-1 border-gray-100 ps-3 ">
                            <div class="font-semibold text-base text-gray-800"><?php echo e($coffee->name); ?></div>
                            <div class="text-green-600 font-semibold text-sm">0 ₴ (по акции)</div>
                            <div class="text-amber-600 text-sm">+ <?php echo e($coffee->delivery_price); ?> ₴ доставка</div>
                        </div>
                    </div>
                </div>
                <div class="grid gap-4">
                    <div>
                        <input wire:model="firstname" type="text" class="w-full rounded-xl bg-white border <?php echo e($errors->has('firstname') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base dark:text-gray-700" placeholder="Имя" />
                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <input wire:model="lastname" type="text" class="w-full rounded-xl bg-white border <?php echo e($errors->has('lastname') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base dark:text-gray-700" placeholder="Фамилия" />
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <input wire:model="email" type="email" class="w-full rounded-xl bg-white border <?php echo e($errors->has('email') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base dark:text-gray-700" placeholder="Email" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Step 2: Адрес доставки -->
            <?php if($step === 2): ?>
                <div class="grid gap-4">
                    <div>
                        <input wire:model="phone" type="tel" class="w-full rounded-xl border <?php echo e($errors->has('phone') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base" placeholder="Телефон" />
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <input wire:model="address" type="text" class="w-full rounded-xl border <?php echo e($errors->has('address') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base" placeholder="Улица, дом, квартира" />
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <input wire:model="zip" type="text" class="w-full rounded-xl border <?php echo e($errors->has('zip') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base" placeholder="Почтовый индекс" />
                        <?php $__errorArgs = ['zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <input wire:model="country" type="text" class="w-full rounded-xl border <?php echo e($errors->has('country') ? 'border-red-500' : 'border-gray-300'); ?> px-4 py-3 text-base" placeholder="Страна" />
                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Step 3: Подтверждение -->
            <?php if($step === 3): ?>
                <div class="bg-white rounded-xl shadow p-4">
                    <h3 class="text-lg font-semibold mb-4">Подтверждение заказа</h3>
                    <div class="mb-4">
                        <p class="text-gray-700">Вы заказываете: <strong><?php echo e($coffee->name); ?></strong></p>
                        <img src="<?php echo e(asset('storage/' . $coffee->image)); ?>" alt="Product image" class="w-32 h-32 object-cover rounded mb-3">
                        <p class="text-gray-700">Стоимость кофе: <span class="font-bold text-green-600">0 ₴ (по акции)</span></p>
                        <p class="text-gray-700">Стоимость доставки: <span class="font-bold text-amber-600"><?php echo e($coffee->delivery_price); ?> ₴</span></p>
                        <p class="text-lg font-semibold mt-2">Итого к оплате: <span class="text-cyan-600"><?php echo e($coffee->delivery_price); ?> ₴</span></p>
                    </div>
                    <p class="text-sm text-gray-500 mb-2">Оплата осуществляется только за доставку. Кофе предоставляется бесплатно в рамках акции.</p>
                    <div class="mt-4 text-sm text-gray-700 space-y-1">
                        <p><strong>Имя:</strong> <?php echo e($firstname); ?></p>
                        <p><strong>Фамилия:</strong> <?php echo e($lastname); ?></p>
                        <p><strong>Email:</strong> <?php echo e($email); ?></p>
                        <p><strong>Телефон:</strong> <?php echo e($phone); ?></p>
                        <p><strong>Адрес:</strong> <?php echo e($address); ?></p>
                        <p><strong>Индекс:</strong> <?php echo e($zip); ?></p>
                        <p><strong>Страна:</strong> <?php echo e($country); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Navigation buttons -->
            <div class="mt-8 flex flex-col sm:flex-row justify-between gap-4">
                <?php if($step > 1): ?>
                    <button wire:click="prevStep" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-gray-200 hover:bg-gray-300 text-gray-800 text-base font-medium">Назад</button>
                <?php else: ?>
                    <span class="w-full sm:w-auto"></span>
                <?php endif; ?>

                <?php if($step < 3): ?>
                    <button wire:click="nextStep" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-semibold shadow text-base">Далее</button>
                <?php else: ?>
                    <button wire:click="submitOrder" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold shadow text-base">Подтвердить заказ</button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('livewire:initialized', () => {
            Livewire.on('set-page-title', (event) => {
                document.title = event.title;
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH H:\OSPanel\home\coffee.loc\resources\views\livewire\coffee-order-form.blade.php ENDPATH**/ ?>