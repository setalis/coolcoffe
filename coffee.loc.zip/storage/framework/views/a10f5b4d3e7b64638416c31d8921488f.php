
<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH H:\OSPanel\home\coffee.loc\vendor\livewire\flux\stubs\resources\views\flux\modal\close.blade.php ENDPATH**/ ?>